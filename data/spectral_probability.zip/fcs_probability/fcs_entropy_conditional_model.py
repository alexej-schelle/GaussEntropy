
################################################################################################################################################################################
#                                                                                                                                                                              #
#                                                                                                                                                                              #
#   This is the code section of fcs_entropy_quant_model.py - a software for modeling the entropy distribution of .fcs and .ssd data (with constant and unique cell number)     # 
#   assuming Gaussian event fluctuations with a Markov sampling algorithm.                                                                                                     #                                                                    #     
#                                                                                                                                                                              #
#                                                                                                                                                                              #
################################################################################################################################################################################    

from ftplib import parse150
import os
import sys
import math
import random
from tabnanny import check
import numpy
import numpy as np
import pylab
import matplotlib.pyplot as plt
import operator
import csv

num_spectrum = 5 # Number of markers in use for FCS data

# Define technical quantities and constants

cell_label = 40 # Total number of cells (unique and constant)
delta_sample = 1.00 # Relative range of the number distribution

# Define internal functions 

def gauss(input_value, input_mean, input_dev):

        gauss_value = 1.0/math.sqrt(2.0)/math.sqrt(math.pi)*math.sqrt(input_dev**2)*math.exp(-((input_value-input_mean)**2/2.0/input_dev**2)) # Gaussian model assumption for energy distribution
        
        return gauss_value

# Define deviations and sampling parameters

sample_size = 100000 # Sample size per patient

event_sample_old = 0.0 # Old value of sampled photon number
event_sample = 0.0 # Actual value of sampled photon number

# Define FCS import matrix

print 'Initialisierung der FCS Inputvektoren'

rows, cols, deepness = (cell_label, num_spectrum, sample_size) # Defines the size of the fcs matrix, i. e. cell_number x num_markers

fcs_event = [[[0.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # The cube matrix fcs_data[k][l][m] defines single probability measures - k --> cell label; l --> marker label; m --> probability label; 
fcs_intensity = [[[0.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # The cube matrix fcs_data[k][l][m] defines single probability measures - k --> cell label; l --> marker label; m --> probability label; 

probability_per_realisation = [[[1.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)]  # Probability distribution of photon number per patient.
entropy_per_realisation = [0.0 for m in range(deepness)] # Entropy distribution per photon number distribution or realisation.

sum_probability_per_realisation = [[[1.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # Sum of probability measures per realisation.
sum_entropy_per_realisation = [0.0 for m in range(deepness)] # Sum of entropy measures per photon number realisation.

norm = [[0.0 for m in range(cols)] for l in range(deepness)] # Norm for standard probability distribution.
sum_norm = [[0.0 for m in range(cols)] for l in range(deepness)] # Norm for sum of probability distribution.

entropy = {"1" : [0.0 for m in range(deepness)], "2" : [0.0 for m in range(deepness)], "3" : [0.0 for m in range(deepness)], "4" : [0.0 for m in range(deepness)], "5" : [0.0 for m in range(deepness)], "12" : [0.0 for m in range(deepness)], "13" : [0.0 for m in range(deepness)], "14" : [0.0 for m in range(deepness)], "15" : [0.0 for m in range(deepness)], "23" : [0.0 for m in range(deepness)], "24" : [0.0 for m in range(deepness)], "25" : [0.0 for m in range(deepness)], "34" : [0.0 for m in range(deepness)], "35" : [0.0 for m in range(deepness)], "45" : [0.0 for m in range(deepness)]} # List for entropy measures

# Read-in and sort FCS data

fcs_import_lines = [] # List for FCS import vectors.

print 'Import und Uebergabe der FCS Inputvektoren'

k = 0
l = 0
m = 0

with open('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fcs_data/fcs_import.csv','r') as f: # Routine for import of FCS vectors.

    for line in f.readlines():
    
        fcs_import = line.split(';')
        k = k + 1

        for l in range(0,num_spectrum):
        
                fcs_event[k-1][l][0] = fcs_import[l] # Transfer start values of intensity to initial state vector of the FCS intensity distribution

# Sample FCS data to different FCS data samples (sampling over photon number and wavelength)

print 'Initialisierung der Berechnung der Event Wahrscheinlichkeiten'

drop = 1

for k in range(0, cell_label): # Sample over cell_label

        fcs_event[k][0][0] = random.uniform(1000.00,1500.00) # Generate initial state for artificial data map
        fcs_event[k][1][0] = random.uniform(1500.00,2500.00)
        fcs_event[k][2][0] = random.uniform(2500.00,3500.00)
        fcs_event[k][3][0] = random.uniform(3500.00,4500.00)
        fcs_event[k][4][0] = random.uniform(4500.00,5500.00)

        print 'Berechnung der Events fuer Teilchenlabel Nr. : ' + str(k)
        
        for l in range(0, num_spectrum): # Sample over num_markers - sample corresponding values for different markers.

                for m in range(0, sample_size):

                        event_sample = random.uniform(float(fcs_event[k][l][0]) - delta_sample*float(fcs_event[k][l][0]), float(fcs_event[k][l][0]) + delta_sample*float(fcs_event[k][l][0])) # Random sample of non-condensate particle number                                                                                                                
                                                
                        if (drop == 1) : 
                                
                                event_sample_old = event_sample

                        if (operator.gt(min(gauss(event_sample,float(fcs_event[k][l][0]),float(fcs_event[k][l][0]))/gauss(event_sample_old,float(fcs_event[k][l][0]),float(fcs_event[k][l][0])),1.00),random.uniform(0.00,1.00))): # Condition for transition to another state at equilibrium

                                drop = 0

                                event_sample_old = event_sample

                                for z in range(0, num_spectrum):

                                        if (l != z) : probability_per_realisation[k][z][m] = float(probability_per_realisation[k][z][m])*gauss(event_sample,float(fcs_event[k][z][0]),float(fcs_event[k][z][0]))

                                sum_probability_per_realisation[k][l][m] = float(sum_probability_per_realisation[k][l][m])*gauss(event_sample,float(fcs_event[k][l][0]),float(fcs_event[k][l][0]))

                                for z in range(0, num_spectrum):

                                        if (l != z) : norm[m][z] = norm[m][z] + probability_per_realisation[k][z][m]

                                sum_norm[m][l] = sum_norm[m][l] + sum_probability_per_realisation[k][l][m]

                        else : 

                                probability_per_realisation[k][l][m] = 0.0
                                sum_probability_per_realisation[k][l][m] = 0.0


# check_norm = 0.0

# for m in range(0, sample_size):

 #       print check_norm
  #      check_norm = 0.0

   #     for k in range(0, cell_label):

    #            check_norm = check_norm + probability_per_realisation[k][m]/norm[m]


for m in range(0, sample_size):

        print 'Berechnung der Entropien fuer die unterschiedlichen Realisierungen : ' + str(m)

        for k in range(0, cell_label): # Sample over cell_number

                for l in range(0, num_spectrum): # Sample over cell_number

                        if (probability_per_realisation[k][l][m] != 0.0):

                                entropy_per_realisation[m] = entropy_per_realisation[m] - probability_per_realisation[k][l][m]/norm[m][l]*math.log(probability_per_realisation[k][l][m]/norm[m][l])

                                for z in range(0, num_spectrum):

                                        if (l == z) : entropy[str(z+1)][m] = entropy[str(z+1)][m] - probability_per_realisation[k][z][m]/norm[m][z]*math.log(probability_per_realisation[k][z][m]/norm[m][z])

                        if (sum_probability_per_realisation[k][l][m] != 0.0):
                        
                                sum_entropy_per_realisation[m] = sum_entropy_per_realisation[m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])

                                if (l == 0 or l == 1) : entropy['12'][m] = entropy['12'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 0 or l == 2) : entropy['13'][m] = entropy['13'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 0 or l == 3) : entropy['14'][m] = entropy['14'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 0 or l == 4) : entropy['15'][m] = entropy['15'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 1 or l == 2) : entropy['23'][m] = entropy['23'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 1 or l == 3) : entropy['24'][m] = entropy['24'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 1 or l == 4) : entropy['25'][m] = entropy['25'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 2 or l == 3) : entropy['34'][m] = entropy['34'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 2 or l == 4) : entropy['35'][m] = entropy['35'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                if (l == 3 or l == 4) : entropy['45'][m] = entropy['45'][m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])


plt.figure(1)
plt.hist2d(sum_entropy_per_realisation, entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_1.png')

plt.figure(2)
plt.hist2d(entropy['1'], sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_2.png')

plt.figure(3)
plt.hist2d(entropy['2'], sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S2', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_3.png')

plt.figure(4)
plt.hist2d(entropy['3'], sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S3', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_4.png')

plt.figure(5)
plt.hist2d(entropy['4'], sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S4', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_5.png')

plt.figure(6)
plt.hist2d(entropy['5'], sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S5', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_6.png')

plt.figure(7)
plt.hist2d(entropy['1'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_7.png')

plt.figure(8)
plt.hist2d(entropy['2'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S2', fontsize = 18)
plt.ylabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_8.png')

plt.figure(9)
plt.hist2d(entropy['3'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S3', fontsize = 18)
plt.ylabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_9.png')

plt.figure(10)
plt.hist2d(entropy['4'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S4', fontsize = 18)
plt.ylabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_10.png')

plt.figure(11)
plt.hist2d(entropy['5'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S5', fontsize = 18)
plt.ylabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_11.png')

plt.figure(12)
plt.hist2d(entropy['1'], entropy['2'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S2', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_12.png')

plt.figure(13)
plt.hist2d(entropy['1'], entropy['3'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S3', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_13.png')

plt.figure(14)
plt.hist2d(entropy['1'], entropy['4'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S4', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_14.png')

plt.figure(15)
plt.hist2d(entropy['1'], entropy['5'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1', fontsize = 18)
plt.ylabel('S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_15.png')

plt.figure(16)
plt.hist2d(entropy['2'], entropy['3'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S2', fontsize = 18)
plt.ylabel('S3', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_16.png')

plt.figure(17)
plt.hist2d(entropy['2'], entropy['4'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S2', fontsize = 18)
plt.ylabel('S4', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_17.png')

plt.figure(18)
plt.hist2d(entropy['2'], entropy['5'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S2', fontsize = 18)
plt.ylabel('S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_18.png')

plt.figure(19)
plt.hist2d(entropy['3'], entropy['5'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S3', fontsize = 18)
plt.ylabel('S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_19.png')

plt.figure(20)
plt.hist2d(entropy['4'], entropy['5'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S4', fontsize = 18)
plt.ylabel('S5', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fig_entropy/fig_entropy_20.png')
