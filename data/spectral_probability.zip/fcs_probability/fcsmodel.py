

################################################################################################################################################################################
#                                                                                                                                                                              #
#                                                                                                                                                                              #
#   This is the code section of fcsmodel.py - a software for modeling the entropy and intensity distribution of .fcs and .ssd data with a Markov sampling algorithm.          # 
#                                                                                                                                                                              #
#                                                                                                                                                                              #
################################################################################################################################################################################    


import os
import sys
import math
import random
import numpy
import numpy as np
import pylab
import matplotlib.pyplot as plt
import operator
import csv

num_markers = 5 # Maximal number of markers over all labs
omega_marker = [0.0 for l in range(num_markers)] # Circular marker frequency in units of Hz

# Define marker spectrum :

omega_marker[0] = 2.0*math.pi*100.0 # Circular frequency # 1 in units of Hz 
omega_marker[1] = 2.0*math.pi*200.0 # Circular frequency # 2 in units of Hz 
omega_marker[2] = 2.0*math.pi*300.0 # Circular frequency # 3 in units of Hz 
omega_marker[3] = 2.0*math.pi*400.0 # Circular frequency # 4 in units of Hz 
omega_marker[4] = 2.0*math.pi*500.0 # Circular frequency # 5 in units of Hz 

# Define technical quantities and constants

cell_number = 100 # Total number of cells (constant)
delta_sample = 1.50 # Relative frequency range of the marker distributions

rhbkb = 7.63822291E-3 # Ratio of hbar and Boltzmann constant
hbar = 1.0545718E-34 # Plancks constant
speed_of_light = 2.99792458E8 # Speed of light in units of meter per second 
Boltzmann_constant = 1.38064852E-23 # Boltzmann constant in units of m2 kg s-2 K-1

# Define internal functions 

def boltzmann_function(input_value, input_temperature):
        
        boltzmann_value = 1.0/2.0/math.pi*math.exp(-input_value/Boltzmann_constant/input_temperature)

        return boltzmann_value


def gauss(input_value, input_mean, variance):

        gauss_value = 1.0/math.sqrt(2.0)/math.sqrt(math.pi)/input_mean*math.exp(-((input_value-input_mean)**2/2.0/variance**2))
        
        return gauss_value


# Define deviations and sampling parameters

sample_size = 10000 # Sample size per patient
overlay_size = 0 # Number of overlayed samples per patient

intensity_sample = 0.0 # Sampled intensity in units of Joule per m and sec
photon_number_sample = 0.0 # Sampled photon number in integer units
energy_sample = 0.0 # Sampled energy in units of Joule
energy_sample_old = 0.0 # Old value of sampled energy in units of Joule
energy_mean = 0.0 # Mean intensity in units of Joule per m and sec

omega_sample = ['']*num_markers # Sampled circular frequency in units of Hz

photon_sample = 0.0

temperature = 25.0 + 273.15 # Reference temperature of the sample in units of Kelvin - typical temperature from 

mean_measurement_time = 1.0E-4 # Mean meaurement time (constant during sampling) - from 5.0E-3 - 5.0E-4 to 
mean_cell_surface = 1.0E-2 # Average surface of a cell in units of nm (constant during sampling) - cell radius from 0.2 - 20 micrometer
mean_cell_mass = 1.0E-4 # Average mass of cell in units of kilogramm (constant during sampling) - typical size on the order of 


# Define FCS import matrix

print 'Initialisierung der FCS Inputvektoren'

rows, cols, deepness = (cell_number, num_markers, sample_size) # Defines the size of the fcs matrix, i. e. cell_number x num_markers

fcs_photon = [[[0.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # The cube matrix fcs_data[k][l][m] defines single probability measures - k --> cell label; l --> marker label; m --> probability label; 
fcs_intensity = [[[0.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # The cube matrix fcs_data[k][l][m] defines single probability measures - k --> cell label; l --> marker label; m --> probability label; 

probability_per_realisation = [[1.0 for k in range(deepness)] for m in range(rows)]
entropy_per_realisation = [0.0 for m in range(deepness)]

sum_probability_per_realisation = [[[1.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)]
sum_entropy_per_realisation = [0.0 for m in range(deepness)]

pre_sum_probability_per_cell_label = [[1.0 for k in range(deepness)] for m in range(rows)]

norm = [0.0 for m in range(deepness)]
sum_norm = [[0.0 for m in range(cols)] for l in range(deepness)]

# Read-in and sort FCS data

fcs_import_lines = []

print 'Import und Uebergabe der FCS Inputvektoren'

k = 0
l = 0
m = 0

with open('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fcs_probability/fcs_data/fcs_import.csv','r') as f:

    for line in f.readlines():
    
        fcs_import = line.split(';')
        k = k + 1

        for l in range(0,num_markers):
        
                fcs_photon[k-1][l][0] = fcs_import[l] # Transfer start values of intensity to initial state vector of the fcs intensity distribution


# Sample FCS data to different FCS data samples (sampling over photon number and wavelength)

print 'Initialisierung der Berechnung der Wahrscheinlichkeiten fuer die probabilistischen FCS Daten'

drop = 1

for k in range(0, cell_number): # Sample over cell_number

        print 'Berechnung der Intensitaeten fuer Zelllabel Nr. : ' + str(k)
        
        for l in range(0, num_markers): # Sample over num_markers - Sample corresponding values for different markers

                for m in range(0, sample_size):

                        photon_sample = random.uniform(float(fcs_photon[k][l][0]) - delta_sample*float(fcs_photon[k][l][0]), float(fcs_photon[k][l][0]) + delta_sample*float(fcs_photon[k][l][0])) # Random sample of non-condensate particle number                                                                                                                
                        omega_sample = random.uniform(float(omega_marker[l]) - delta_sample*float(omega_marker[l]), omega_marker[l] + delta_sample*float(omega_marker[l])) # Random sample of non-condensate particle number                                                                                                                

                        energy_sample = hbar*photon_sample*omega_marker[l]
                        energy_mean = hbar*float(fcs_photon[k][l][0])*omega_marker[l]

                        if (energy_mean == 0.0) : energy_mean = 1.0
                        
                        if (drop == 1) : energy_sample_old = energy_sample

                        if (operator.gt(min((math.exp(energy_sample_old/Boltzmann_constant/temperature))/(math.exp(energy_sample/Boltzmann_constant/temperature)),1.00),random.uniform(0.00,1.00))): # Condition for transition to another state at equilibrium
                        
                                if (operator.gt(min((math.exp((energy_sample-energy_mean)**2/energy_mean))/(math.exp((energy_sample_old-energy_mean)**2/energy_mean)),1.00),random.uniform(0.00,1.00))): # Condition for transition to another state at equilibrium

                                        drop = 0

                                        energy_sample_old = energy_sample
                                        fcs_intensity[k][l][m] = hbar*omega_sample*photon_sample/mean_cell_surface/mean_measurement_time#*omega_marker[l]**4/omega_sample**4 # From here, physical intensity is defined. Start values of the sample are at m = 0                        

                                        probability_per_realisation[k][m] = float(probability_per_realisation[k][m])*boltzmann_function(energy_sample, temperature)*gauss(energy_sample,energy_mean,energy_mean)
                                        sum_probability_per_realisation[k][l][m] = float(sum_probability_per_realisation[k][l][m])*boltzmann_function(energy_sample, temperature)*gauss(energy_sample,energy_mean,energy_mean)
                                       
                                        norm[m] = float(norm[m]) + float(probability_per_realisation[k][m])
                                        sum_norm[m][l] = float(sum_norm[m][l]) + float(sum_probability_per_realisation[k][l][m])


for m in range(0, sample_size):

        print 'Berechnung der Entropien fuer die unterschiedlichen Realisierungen : ' + str(m)

        for k in range(0, cell_number): # Sample over cell_number

                entropy_per_realisation[m] = entropy_per_realisation[m] - probability_per_realisation[k][m]/norm[m]*math.log(probability_per_realisation[k][m]/norm[m])
               
                for l in range(0, num_markers): # Sample over cell_number

                        sum_entropy_per_realisation[m] = sum_entropy_per_realisation[m] - sum_probability_per_realisation[k][l][m]/sum_norm[m][l]*math.log(sum_probability_per_realisation[k][l][m]/sum_norm[m][l])
                                


plt.figure(1)
plt.hist(entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S12', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fig_entropy_1.png')

plt.figure(2)
plt.hist(sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1 + S2', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fig_entropy_2.png')

plt.figure(3)
plt.hist2d(entropy_per_realisation, sum_entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S12', fontsize = 18)
plt.ylabel('S1 + S2', fontsize = 18)
plt.savefig('/Users/AS_Scientific_Analytics/Desktop/fcsmodel/fig_entropy_3.png')

