
################################################################################################################################################################################
#                                                                                                                                                                              #
#                                                                                                                                                                              #
#   This is the code section of spectral_entropy_model.py - a software for modeling the entropy distribution of spectral data (with constant and unique particle number)       # 
#   assuming Gaussian event fluctuations with a Markov sampling algorithm.                                                                                                     #                                                                    #     
#                                                                                                                                                                              #
#                                                                                                                                                                              #
################################################################################################################################################################################    

from ftplib import parse150
import os
import sys
import math
import random
from tabnanny import check
import numpy
import numpy as np
import pylab
import matplotlib.pyplot as plt
import operator
import csv

num_spectrum = 5 # Number of frequency components in use for spectral data

# Define technical quantities and constants

particle_label = 40 # Total number of particles (unique and constant)
delta_sample = 1.00 # Relative range of the number distribution

# Define internal gauss function

def gauss(input_value, input_mean, input_dev):

        gauss_value = 1.0/math.sqrt(2.0)/math.sqrt(math.pi)*math.sqrt(input_dev**2)*math.exp(-((input_value-input_mean)**2/2.0/input_dev**2)) # Gaussian model assumption for energy distribution
        
        return gauss_value

# Define function to calculate probability measure

def probability_measure(i, j, k, l, input_array, epsilon): # Calculates the conditional probabilty between the input matrices S_ij and S_kl.

        measure = 0.0
        
        for m in range(0, sample_size):

                for n in range(0, sample_size):
                        
                        if ((input_array[str(i)][m] - input_array[str(k)][n]) <= epsilon and (input_array[str(j)][m] - input_array[str(l)][n]) <= epsilon) : 

                                measure = measure + 1.00

        return measure

# Define deviations and sampling parameters

sample_size = 100000 # Sample size per patient

event_sample_old = 0.0 # Old value of sampled photon number
event_sample = 0.0 # Actual value of sampled photon number

# Define spectral import matrix

print 'Initialisierung der spectral Inputvektoren'

rows, cols, deepness = (particle_label, num_spectrum, sample_size) # Defines the size of the spectral matrix, i.e. particle_number times num_components

spectral_events = [[[0.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # The cube matrix spectral_events[k][l][m] defines single probability measures - k --> particle label; l --> marker label; m --> probability label; 

probability_per_realisation = [[1.0 for k in range(deepness)] for m in range(rows)] # Probability distribution of photon number per realisation.
entropy_per_realisation = [0.0 for m in range(deepness)] # Entropy distribution per photon number distribution or realisation.

sum_probability_per_realisation = [[[1.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)] # Sum of probability measures per realisation.
sum_entropy_per_realisation = [0.0 for m in range(deepness)] # Sum of entropy measures per photon number realisation.

conditional_probability_per_realisation = [[[1.0 for k in range(deepness)] for l in range(cols)] for m in range(rows)]  # Sum of probability measures per realisation.

norm = [0.0 for m in range(deepness)] # Norm for standard probability distribution.
sum_norm = [[0.0 for m in range(cols)] for l in range(deepness)] # Norm for sum of probability distribution.
conditional_norm = [[0.0 for m in range(cols)] for l in range(deepness)] # Norm for conditional probability distribution.

spectral_mean_number = [0.0 for k in range(cols)] # Average occupation number as a function of frequency component.

entropy = {"1" : [0.0 for m in range(deepness)], "2" : [0.0 for m in range(deepness)], "3" : [0.0 for m in range(deepness)], "4" : [0.0 for m in range(deepness)], "5" : [0.0 for m in range(deepness)], "12" : [0.0 for m in range(deepness)], "13" : [0.0 for m in range(deepness)], "14" : [0.0 for m in range(deepness)], "15" : [0.0 for m in range(deepness)], "23" : [0.0 for m in range(deepness)], "24" : [0.0 for m in range(deepness)], "25" : [0.0 for m in range(deepness)], "34" : [0.0 for m in range(deepness)], "35" : [0.0 for m in range(deepness)], "45" : [0.0 for m in range(deepness)]} # List for entropy measures
conditional_entropy = {"1" : [0.0 for m in range(deepness)], "2" : [0.0 for m in range(deepness)], "3" : [0.0 for m in range(deepness)], "4" : [0.0 for m in range(deepness)], "5" : [0.0 for m in range(deepness)], "12" : [0.0 for m in range(deepness)], "13" : [0.0 for m in range(deepness)], "14" : [0.0 for m in range(deepness)], "15" : [0.0 for m in range(deepness)], "23" : [0.0 for m in range(deepness)], "24" : [0.0 for m in range(deepness)], "25" : [0.0 for m in range(deepness)], "34" : [0.0 for m in range(deepness)], "35" : [0.0 for m in range(deepness)], "45" : [0.0 for m in range(deepness)]} # List for entropy measures
sum_conditional_entropy = [0.0 for m in range(deepness)] # Sum of conditional entropy

conditional_entropy_difference = {"12" : [[0.0 for m in range(deepness)] for l in range(deepness)], "23" : [[0.0 for m in range(deepness)] for l in range(deepness)], "34" : [[0.0 for m in range(deepness)] for l in range(deepness)], "45" : [[0.0 for m in range(deepness)] for l in range(deepness)]} # List for entropy measures

mean_entropy = 0.0 # Definition of mean entropy
mean_sum_entropy = 0.0 # Definition of mean of the sum of entropies
mean_conditional_entropy = [0.0 for m in range(particle_label)] # Definition of mean of conditional entropy

relative_mean_conditional_entropy = [0.0 for m in range(cols)] # Mean relative/percentual (from total) conditional entropy

total_conditional_entropy = 0.0 # Sum of conditional entropies

# Read-in and sort spectral data

spectral_import_lines = [] # List for spectral import vectors.

print 'Import und Uebergabe der spectral Inputvektoren'

k = 0
l = 0
m = 0

check_num_particles = 0

with open('/.../spectral_import.csv','r') as f: # Routine for import of spectral vectors.

    for line in f.readlines():
    
        spectral_import = line.split(';')

        k = k + 1
        check_num_particles = check_num_particles + 1

        for l in range(0,num_spectrum):
        
                spectral_events[k-1][l][0] = spectral_import[l] # Transfer start values of intensity to initial state vector of the spectral intensity distribution

# Check particle number dimension

if (check_num_particles != particle_label) : 
        
        print 'Anzahl der Teilchen im externen File stimmt nicht mit der Angabe der Inputzellen ueberein'
        #exit()

for k in range(0, particle_label): 

        spectral_events[k][0][0] = random.gauss(2000.0,2000.0)
        spectral_events[k][1][0] = random.gauss(5000.0,5000.0)
        spectral_events[k][2][0] = random.gauss(2000.0,2000.0)
        spectral_events[k][3][0] = random.gauss(2000.0,2000.0)
        spectral_events[k][4][0] = random.gauss(2000.0,2000.0)

# Calculate average occupation number as a function of frequency component

for k in range(0, particle_label): 

        for l in range(0, num_spectrum):

                spectral_mean_number[l] = spectral_mean_number[l] + float(spectral_events[k][l][0])/float(particle_label)

# Sample fluorescence spectrum given the input spectral data sample (sampling over photon number)

print 'Initialisierung der Berechnung der Event Wahrscheinlichkeiten'

drop = 1

for k in range(0, particle_label): # Sample over particle labels

        print 'Berechnung der Eventwahrscheinlichkeiten fuer Teilchenlabel Nr. : ' + str(k)
        
        for l in range(0, num_spectrum): # Sample over num_components - sample corresponding values for different frequency components
                        
                for m in range(0, sample_size):

                        event_sample = random.uniform(float(spectral_events[k][l][0]) - delta_sample*float(spectral_events[k][l][0]), float(spectral_events[k][l][0]) + delta_sample*float(spectral_events[k][l][0])) # Random sample of particle number distribution                                                                                                               
                                                
                        if (drop == 1) : 
                                
                                event_sample_old = event_sample

                        if (operator.gt(min(gauss(event_sample,float(spectral_mean_number[l]),float(spectral_mean_number[l]))/gauss(event_sample_old,float(spectral_mean_number[l]),float(spectral_mean_number[l])),1.00),random.uniform(0.00,1.00))): # Condition for transition to another state at equilibrium

                                drop = 0

                                event_sample_old = event_sample

                                probability_per_realisation[k][m] = float(probability_per_realisation[k][m])*gauss(event_sample,float(spectral_events[k][l][0]),float(spectral_events[k][l][0]))
                                sum_probability_per_realisation[k][l][m] = float(sum_probability_per_realisation[k][l][m])*gauss(event_sample,float(spectral_events[k][l][0]),float(spectral_events[k][l][0]))

                                norm[m] = norm[m] + probability_per_realisation[k][m]
                                sum_norm[m][l] = sum_norm[m][l] + sum_probability_per_realisation[k][l][m]

                         # Calculate conditional probability for different sampling steps

                                for z in range(0, num_spectrum):

                                        if (z != l) : conditional_probability_per_realisation[k][z][m] = float(conditional_probability_per_realisation[k][z][m])*gauss(event_sample,float(spectral_events[k][z][0]),float(spectral_events[k][z][0]))
                                      
                                for z in range(0, num_spectrum):

                                        if (z != l) : conditional_norm[m][z] = conditional_norm[m][z] + conditional_probability_per_realisation[k][z][m]

                        else : 

                                probability_per_realisation[k][m] = 0.0
                                sum_probability_per_realisation[k][l][m] = 0.0
                                conditional_probability_per_realisation[k][z][m] = 0.0

# for k in range(0, particle_label):
#
#       for m in range(0, sample_size):
#
#               check_norm = check_norm + conditional_probability_per_realisation[k][0][m]/conditional_norm[m][0]/float(sample_size)
#

for m in range(0, sample_size): # Sample over realisations
     
        print 'Berechnung der Entropien fuer die unterschiedlichen Realisierungen : ' + str(m)
      
        for k in range(0, particle_label): # Sample over particle_number
             
                if (probability_per_realisation[k][m] != 0.0):

                        entropy_per_realisation[m] = entropy_per_realisation[m] - float(probability_per_realisation[k][m])/float(norm[m])*float(math.log(float(probability_per_realisation[k][m])/float(norm[m]))) # Calculate standard entropy per realisation 
                          
                for l in range(0, num_spectrum): # Sample over marker number
                    
                        if (sum_probability_per_realisation[k][l][m] != 0.0):
                        
                                sum_entropy_per_realisation[m] = float(sum_entropy_per_realisation[m]) - float(sum_probability_per_realisation[k][l][m])/float(sum_norm[m][l])*math.log(float(sum_probability_per_realisation[k][l][m])/float(sum_norm[m][l]))
                                                            
                                for z in range(0, num_spectrum):

                                        if (z == l) : entropy[str(z+1)][m] = float(entropy[str(z+1)][m]) - float(sum_probability_per_realisation[k][l][m])/float(sum_norm[m][l])*math.log(float(sum_probability_per_realisation[k][l][m])/float(sum_norm[m][l]))
                    
                        if (conditional_probability_per_realisation[k][l][m] != 0.0):
                            
                                for z in range(0, num_spectrum): # Entropy of conditional probability samples per realisation

                                        if (l == z) : conditional_entropy[str(z+1)][m] = float(conditional_entropy[str(z+1)][m]) - float(conditional_probability_per_realisation[k][z][m])/float(conditional_norm[m][z])*float(math.log(float(conditional_probability_per_realisation[k][z][m])/float(conditional_norm[m][z])))
                                                        
for m in range(0, sample_size): # Calculate mean values of standard entropy, sum of standard entropies, conditional entropy and sum of conditional entropies
              
        mean_entropy = mean_entropy + float(entropy_per_realisation[m])/float(sample_size) # Calculate mean entropy
        mean_sum_entropy = mean_sum_entropy + float(sum_entropy_per_realisation[m])/float(sample_size) # Calculate mean of sum of entropies

        for l in range(0, num_spectrum):

                sum_conditional_entropy[m] = sum_conditional_entropy[m] + float(conditional_entropy[str(l+1)][m]) # Calculate mean of sum of conditional entropies
                mean_conditional_entropy[l] = mean_conditional_entropy[l] + float(conditional_entropy[str(l+1)][m])/float(sample_size) # Calculate mean of conditional entropies
                              
for l in range(0, num_spectrum): # Calculate total conditional entropy over frequency components

        total_conditional_entropy = total_conditional_entropy + float(mean_conditional_entropy[l])     
        
for z in range(0, num_spectrum): # Calculate mean relative conditional entropy for each frequency component

        relative_mean_conditional_entropy[z] = float(mean_conditional_entropy[z])/float(total_conditional_entropy)
                
# print 'Konditionelle Wahrscheinlichkeiten'
#                             
# print ' '
#
# print 'S_12 / S_12 : ', probability_measure(1,2,1,2,conditional_entropy,0.50)/probability_measure(1,2,1,2,conditional_entropy,0.50)*100.0, ' %'
# print 'S_12 / S_23 : ', probability_measure(1,2,2,3,conditional_entropy,0.50)/probability_measure(2,3,2,3,conditional_entropy,0.50)*100.0, ' %'
#
# print 'Mittlere Entropie : ', mean_entropy
# print 'Mittlere summierte Entropie : ', mean_sum_entropy
# print 'Mittlere konditionierte Entropie : ', mean_conditional_entropy[0], mean_conditional_entropy[1], mean_conditional_entropy[2], mean_conditional_entropy[3], mean_conditional_entropy[4]
# print 'Mittlere relative konditionierte Entropie : ', relative_mean_conditional_entropy[0]*100.0, '%', relative_mean_conditional_entropy[1]*100.0, '%', relative_mean_conditional_entropy[2]*100.0, '%', relative_mean_conditional_entropy[3]*100.0, '%', relative_mean_conditional_entropy[4]*100.0, '%'

plt.figure(1)
plt.hist2d(sum_entropy_per_realisation, entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('S1+S2+S3+S4+S5', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_1.png')

plt.figure(2)
plt.hist2d(conditional_entropy['1'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S1>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_2.png')

plt.figure(3)
plt.hist2d(conditional_entropy['2'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S2>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_3.png')

plt.figure(4)
plt.hist2d(conditional_entropy['3'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S3>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_4.png')

plt.figure(5)
plt.hist2d(conditional_entropy['4'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S4>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_5.png')

plt.figure(6)
plt.hist2d(conditional_entropy['5'], entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S5>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_6.png')

plt.figure(7)
plt.hist2d(conditional_entropy['1'], conditional_entropy['2'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S1>', fontsize = 18)
plt.ylabel('<S2>', fontsize = 18)
plt.savefig('/.../fig_entropy_7.png')

plt.figure(8)
plt.hist2d(conditional_entropy['2'], conditional_entropy['3'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S2>', fontsize = 18)
plt.ylabel('<S3>', fontsize = 18)
plt.savefig('/.../fig_entropy_8.png')

plt.figure(9)
plt.hist2d(conditional_entropy['3'], conditional_entropy['4'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S3>', fontsize = 18)
plt.ylabel('<S4>', fontsize = 18)
plt.savefig('/.../fig_entropy_9.png')

plt.figure(10)
plt.hist2d(conditional_entropy['4'], conditional_entropy['5'], bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S4>', fontsize = 18)
plt.ylabel('<S5>', fontsize = 18)
plt.savefig('/.../fig_entropy_10.png')

plt.figure(11)
plt.hist2d(sum_conditional_entropy, entropy_per_realisation, bins = 300, normed = True)
plt.tick_params(axis='both', which='major', labelsize = 16)
plt.xlabel('<S1>+<S2>+<S3>+<S4>+<S5>', fontsize = 18)
plt.ylabel('S', fontsize = 18)
plt.savefig('/.../fig_entropy_11.png')